<?php
namespace Aura\SqlQuery\Sqlite;

use Aura\SqlQuery\Common;

class SelectTest extends Common\SelectTest
{
    protected $db_type = 'sqlite';
}
